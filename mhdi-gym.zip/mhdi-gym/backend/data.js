import bcrypt from 'bcryptjs';

const data = {
  users: [
    {
      name: 'admin',
      email: 'admin@example.com',
      password: bcrypt.hashSync('123456'),
      isAdmin: true,
    },
    {
      name: 'user',
      email: 'user@example.com',
      password: bcrypt.hashSync('123456'),
      isAdmin: false,
    },
    {
      name: 'mhdi',
      email: 'mhdi@example.com',
      password: bcrypt.hashSync('123456'),
      isAdmin: false,
    },
  ],
  products: [
    {
      name: 'חלבון 1',
      slug: 'hlvon-1',
      category: 'חלבון',
      image: '/images/h1.jpeg', 
      price: 150,
      countInStock: 1,
    },
    {
      name:  'חלבון 2',
      slug: 'hlvon-2',
      category: 'חלבון',
      image: '/images/h2.jpeg',
      price: 120,
      countInStock: 1,
    },
    {
      name: 'בגד 1',
      slug: 'bgd-1',
      category: 'בגדים',
      image: '/images/l1.jpeg',
      price: 250,
      countInStock: 0,
    },
    {
      name: 'בגד 2',
      slug: 'bgd-2',
      category: 'בגדים',
      image: '/images/l2.png',
      price: 200,
      countInStock: 1,
    },
    {
      name: 'בקובוק 1',
      slug: 'bkbko-1',
      category: 'בקבוקים',
      image: '/images/b1.jpeg',
      price: 35,
      countInStock: 0,
    },
    {
      name: 'בקבבוק 2',
      slug: 'bkbko-2',
      category: 'בקבוקים',
      image: '/images/b2.jpeg',
      price: 65,
      countInStock: 1,
    },
  ],
};
export default data;

import React, { useContext, useEffect, useReducer } from 'react';
import axios from 'axios';
import LoadingComponent from '../components/LoadingComponent';
import AlertComponent from '../components/AlertComponent';
import { Store } from '../Store';
import { getError } from '../utils';

const reducer = (state, action) => {
  switch (action.type) {
    case 'FETCH_REQUEST':
      return { ...state, loading: true };
    case 'FETCH_SUCCESS':
      return { ...state, orders: action.payload, loading: false };
    case 'FETCH_FAIL':
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};

export default function OrderHistoryView() {
  const { state } = useContext(Store);
  const { userInfo } = state;

  const [{ loading, error, orders }, dispatch] = useReducer(reducer, {
    loading: true,
    error: '',
  });
  useEffect(() => {
    const fetchData = async () => {
      dispatch({ type: 'FETCH_REQUEST' });
      try {
        const { data } = await axios.get(
          `/api/orders/mine`,

          { headers: { Authorization: `Bearer ${userInfo.token}` } }
        );
        dispatch({ type: 'FETCH_SUCCESS', payload: data });
      } catch (error) {
        dispatch({
          type: 'FETCH_FAIL',
          payload: getError(error),
        });
      }
    };
    fetchData();
  }, [userInfo]);
  return (
    <div>


      <h1>ההזמנות</h1>
      {loading ? (
        <LoadingComponent></LoadingComponent>
      ) : error ? (
        <AlertComponent variant="danger">{error}</AlertComponent>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>זיהוי</th>
              <th>תאריך</th>
              <th>ס״ה</th>
              <th>שולם</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order._id}>
                <td>{order._id}</td>
                <td>{order.createdAt.substring(0, 10)}</td>
                <td>{order.totalPrice.toFixed(2)}</td>
                <td>{order.isPaid ? order.paidAt.substring(0, 10) : 'לא'}</td>

              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import HomeView from './views/HomeView';
import Navbar from 'react-bootstrap/Navbar';
import Badge from 'react-bootstrap/Badge';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Container from 'react-bootstrap/Container';
import { LinkContainer } from 'react-router-bootstrap';
import { useContext, useEffect, useState } from 'react';
import { Store } from './Store';
import ViewScreen from './views/ViewScreen';
import SigninView from './views/SigninView';
import SignupView from './views/SignupView';
import PaymentMethodView from './views/PaymentMethodView';
import PlaceOrderView from './views/PlaceOrderView';
import OrderScreen from './views/OrderScreen';
import OrderHistoryView from './views/OrderHistoryView';
import ProfileSView from './views/ProfileSView';
import { getError } from './utils';
import axios from 'axios';
import SearchView from './views/SearchView';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardView from './views/DashboardView';
import AdminRoute from './components/AdminRoute';
import ProductListView from './views/ProductListView';
import ProductEditView from './views/ProductEditView';
import OrderListView from './views/OrderListView';
import UserListView from './views/UserListView';
import UserEditView from './views/UserEditView';
import CategoryDropdownComponent from './components/CategoryDropdownComponent';

function App() {
  const { state, dispatch: ctxDispatch } = useContext(Store);
  const { cart, userInfo } = state;

  const signoutHandler = () => {
    ctxDispatch({ type: 'USER_SIGNOUT' });
    localStorage.removeItem('userInfo');
    localStorage.removeItem('shippingAddress');
    localStorage.removeItem('paymentMethod');
    window.location.href = '/signin';
  };
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const { data } = await axios.get(`/api/products/categories`);
        setCategories(data);
      } catch (err) {
        toast.error(getError(err));
      }
    };
    fetchCategories();
  }, []);
  return (
    <BrowserRouter>
      <div

      >
        <ToastContainer position="bottom-center" limit={1} />
        <header>
          <Navbar bg="lite" variant="lite" expand="lg">
            <Container>
 

              <LinkContainer to="/">
                <Navbar.Brand>חדר כושר מהדי</Navbar.Brand>
              </LinkContainer>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
              
                <Nav className="me-auto  w-100  justify-content-end">

             
                  {userInfo ? (
                    <NavDropdown title={userInfo.name} id="basic-nav-dropdown">
                      <LinkContainer to="/profile">
                        <NavDropdown.Item>איזור אישי</NavDropdown.Item>
                      </LinkContainer>
                      <LinkContainer to="/orderhistory">
                        <NavDropdown.Item>היסטוריה להזמנות</NavDropdown.Item>
                      </LinkContainer>
                      <NavDropdown.Divider />
                      <Link
                        className="dropdown-item"
                        to="#signout"
                        onClick={signoutHandler}
                      >
                        יציאה
                      </Link>
                    </NavDropdown>
                  ) : (
                    <Link className="nav-link" to="/signin">
                      התחבר
                    </Link>
                  )}
                  {userInfo && userInfo.isAdmin && (
                    <NavDropdown title="מנהל" id="admin-nav-dropdown">
                      <LinkContainer to="/admin/dashboard">
                        <NavDropdown.Item>דאשבורד</NavDropdown.Item>
                      </LinkContainer>
                      <LinkContainer to="/admin/products">
                        <NavDropdown.Item>מוצרים</NavDropdown.Item>
                      </LinkContainer>
                      <LinkContainer to="/admin/orders">
                        <NavDropdown.Item>הזמנות</NavDropdown.Item>
                      </LinkContainer>
                      <LinkContainer to="/admin/users">
                        <NavDropdown.Item>משתמשים</NavDropdown.Item>
                      </LinkContainer>
                    </NavDropdown>
                  )}
                </Nav>

                <Nav className="me-auto  w-100  justify-content-end">
  {categories.length > 0 && <CategoryDropdownComponent categories={categories} />}
</Nav>
<Link to="/cart" className="nav-link">
                  <i className="fas fa-shopping-basket"></i>

                    {cart.cartItems.length > 0 && (
                      <Badge pill bg="danger">
                        {cart.cartItems.reduce((a, c) => a + c.quantity, 0)}
                      </Badge>
                    )}
                  </Link>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </header>

        <main>
          <Container>
            <Routes>
              <Route path="/cart" element={<ViewScreen />} />
              <Route path="/search" element={<SearchView />} />
              <Route path="/signin" element={<SigninView />} />
              <Route path="/signup" element={<SignupView />} />

       

              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <ProfileSView />
                  </ProtectedRoute>
                }
              />

              <Route path="/placeorder" element={<PlaceOrderView />} />
              <Route
                path="/order/:id"
                element={
                  <ProtectedRoute>
                    <OrderScreen />
                  </ProtectedRoute>
                }
              ></Route>
              <Route
                path="/orderhistory"
                element={
                  <ProtectedRoute>
                    <OrderHistoryView />
                  </ProtectedRoute>
                }
              ></Route>
              <Route path="/payment" element={<PaymentMethodView />}></Route>
              {/* Admin Routes */}
              <Route
                path="/admin/dashboard"
                element={
                  <AdminRoute>
                    <DashboardView />
                  </AdminRoute>
                }
              ></Route>
              <Route
                path="/admin/orders"
                element={
                  <AdminRoute>
                    <OrderListView />
                  </AdminRoute>
                }
              ></Route>
              <Route
                path="/admin/users"
                element={
                  <AdminRoute>
                    <UserListView />
                  </AdminRoute>
                }
              ></Route>
              <Route
                path="/admin/products"
                element={
                  <AdminRoute>
                    <ProductListView />
                  </AdminRoute>
                }
              ></Route>
              <Route
                path="/admin/product/:id"
                element={
                  <AdminRoute>
                    <ProductEditView />
                  </AdminRoute>
                }
              ></Route>
              <Route
                path="/admin/user/:id"
                element={
                  <AdminRoute>
                    <UserEditView />
                  </AdminRoute>
                }
              ></Route>

              <Route path="/" element={<HomeView />} />
            </Routes>
          </Container>
        </main>
        <footer>
          <div className="text-center">חדר כושר מהדי</div>
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;

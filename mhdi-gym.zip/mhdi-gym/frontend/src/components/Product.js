import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useContext } from 'react';
import { Store } from '../Store';

function Product(props) {
  const { product } = props;

  const { state, dispatch: ctxDispatch } = useContext(Store);
  const {
    cart: { cartItems },
  } = state;

  const addToCartHandler = async (item) => {
    const existItem = cartItems.find((x) => x._id === product._id);
    const quantity = existItem ? existItem.quantity + 1 : 1;
    const { data } = await axios.get(`/api/products/${item._id}`);
    if (data.countInStock < quantity) {
      window.alert('המוצר שבחרתה אוזל מהמלאי');
      return;
    }else{
      window.alert('מוצר נוסף לעגלה');
    }
    ctxDispatch({
      type: 'CART_ADD_ITEM',
      payload: { ...item, quantity },
    });
  };

  return (
    <Card>
      {product.countInStock === 0 ? (
          <h5 className='outofstock'>
            אוזל מהמלאי
          </h5>
        ) : (
          <h6>
         
        </h6>
        )}
        <img src={product.image} className="card-img-top" alt={product.name} />
      <Card.Body>
      <Link onClick={(event) => { event.preventDefault(); addToCartHandler(product); }}  >{`להוסיף לסל: ${product.name}`}</Link>
        <Card.Text>₪{product.price}</Card.Text>
       
      </Card.Body>
    </Card>
  );
}
export default Product;      
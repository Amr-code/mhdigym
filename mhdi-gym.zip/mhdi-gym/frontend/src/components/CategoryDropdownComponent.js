import React from 'react';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { LinkContainer } from 'react-router-bootstrap';

const CategoryDropdownComponent = ({ categories }) => {
  return (
    <NavDropdown title="קטגוריות" id="basic-nav-dropdown">
      {categories.map((category) => (
        <LinkContainer
          key={category}
          to={{ pathname: '/search', search: `category=${category}` }}
        >
          <NavDropdown.Item>{category}</NavDropdown.Item>
        </LinkContainer>
      ))}
    </NavDropdown>
  );
};

export default CategoryDropdownComponent;
